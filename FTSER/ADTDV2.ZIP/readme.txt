
Introduction to the td.lib time/date library:

I was recently doing some research on the Civil War and needed to work
with dates and times for that period. I needed to be able to quickly
and accurately perform time and date calculations, view calendars, make
conversions, and print that information to files in a variety of formats.
Needless to say, the functions provided by ANSI were completely inadequate.
No functions for dates before 1900 were provided, strftime() did not work,
which meant not only could I not directly work with these dates and times,
they could not even be directly formatted and printed.
difftime() did'nt work either.

Another problem was with the tm structure itself; the system allocates
and deallocates the memory space for the structure and simply overwrites
the time/date fields when additional calls are made. Trying to work with
multiple instances of the structure caused a number of system crashes.
The time field of the tm structure is on a take-it-or-leave-it 24hr clock,
the month field	is a counter-intuitive 0-11, and the year field is
"year-1900" end of story.

Simply said, the programmer must work with the unwieldy	tm structure and
its initialization, make numerous date and time conversions and then
concatenate strings for formatting etc. etc. taking too much time away
from the programmer.

I wanted time and date routines to be easy enough for the beginning progra
mmer to quickly learn and use. The programmer should be able to simply
declare a predefined time/date type, load its fields with either the
current time and date settings, or any other time and date, and then 
start using it.

I did'nt need to calculate moon phases, solar eclipses, cyclic multiphase
harmonic patterns, or even dog years. After searching the web for quite
awhile, that type of code or libraries was about all I found. 
The ones that did a fairly good job were too complicated to quickly learn
and use and did not comply with	the ANSI format specifiers, which is what
I am used to, so I decided to roll my own.

The result is this small time/date library which will provide all of
the basic functionality needed to perform from fast print-the-time-and-date
statements to more complicated time/date routines. Functions are provided
for practical applications that the programmer is most likely to encounter
- not for rarely used moon phases and such.
 
The library uses the cross-over date of Oct. 1582 and calendar convention
of January 1 being the beginning of the new year. The calendrical
method is proleptic. Detailed discussions of Julian and Gregorian
calendars are widely available and so won't be discussed here.

The library was compiled using Borland's C++ 4.5 in the small memory
model (which means the code you link it to must also be compiled in
the small memory model) and is fully ANSI compliant. I use the functions
contained in the library on Unix and in a Windows 95 dos box.
All that is required is a 386 or higher IBM compatible PC.
A small demo is provided to show some easy examples of how you can
use the library.

(For Unix info see "howto.txt")

The library is free and may be used however you wish. However, if this
zip file is redistributed it must contain the original unaltered files:

readme.txt
howto.txt
demo.exe
demo.c
cal.c
datelib.h
td.lib

If you need a different memory model or have questions, or comments,
drop me a line at: <  bt0202@broncho.ucok.edu  > be sure to include
your e-mail address for a reply.
I will make all source code available for those who request it for
a limited time.


I am currently working on an "uninstaller" application that will
remove EVERY trace of an unwanted program and will rival any of
the commercially available software. The MSDOS version will probably
be free but any Windows versions will not.
(You should be aware that the Windows 95 "Add/Remove Programs" 
application is only useful when	programmers VOLUNTARILY record
certain entries into the registry.
I have installed dozens of programs that when uninstalled left
the registry littered with invalid references to the program!)


Brady Tippit  1-26-97
University of Central Oklahoma

